#include "View.h"

int main()
{
    View view;
    view.mostrarMenu();

    return 0;
}